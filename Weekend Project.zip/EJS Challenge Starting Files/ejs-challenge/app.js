//jshint esversion:6

const express = require("express");
const bodyParser = require("body-parser");
const ejs = require("ejs");
const _ = require('lodash');

const homeStartingContent = "Home Lacus vel facilisis volutpat est velit egestas dui id ornare...";
const aboutContent = "About Hac habitasse platea dictumst vestibulum rhoncus est pellentesque...";
const contactContent = "Contact Scelerisque eleifend donec pretium vulputate sapien...";
const app = express();

//ARRAY TO STORE BLOG POSTS
var postContent = [];

app.set('view engine', 'ejs');

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static("public"));

app.get("/about", function(req, res) {
  res.render("about.ejs", { aboutContent: aboutContent });
});

app.get("/compose", function(req, res) {
  res.render("compose.ejs", {});
});

app.post("/compose", function(req, res) {
  let composeTitle = req.body.postTitle;

  let composeBody = req.body.postBody;

  postContent.push({ title: composeTitle, content: composeBody });
  res.redirect("/");
});

app.get("/contact", function(req, res) {
  res.render("contact.ejs", { contactContent: contactContent });
});

app.get("/", function(req, res) {
  res.render("home.ejs", { postContent: postContent });
});

app.get('/posts/:topic', function(req, res) {
  const requestedTitle = _.lowerCase(req.params.topic);

  console.log(postContent); // Add this line to debug

  for (let post of postContent) {
    const storedTitle = _.lowerCase(post.title);

    if (requestedTitle === storedTitle) {
      res.render('post', {
        title: post.title,
        content: post.content,
      });
    }
  }
});




app.listen(3000, function() {
  console.log("Server started on port 3000");
});
